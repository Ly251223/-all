# LSTM_Battery_RUL_Prediction_

## Data


07.01:  
#### read_data.py
先用实验电池生命周期数据训练出一个基本模型，之后基于基本模型针对具体电池进行训练和测试？

